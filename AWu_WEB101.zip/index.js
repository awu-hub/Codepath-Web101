
/*** Dark Mode ***
  
  Purpose:
  - Use this starter code to add a dark mode feature to your website.

  When To Modify:
  - [ ] Project 5 (REQUIRED FEATURE) 
  - [ ] Any time after
***/

// Step 1: Select the theme button
let toggleButton = document.getElementById("theme-button");
// Step 2: Write the callback function
const toggleDarkMode = () => {
   changeImage();
    document.body.classList.toggle("dark-mode");
    document.documentElement.classList.toggle("dark-mode");
    // Write your code here
    // This section will run whenever the button is clicked
}

const image = document.getElementById("header-img");
const changeImage = () => {
  if (image.src.includes("website_image_header_dark.jpg")) {
    image.src = "img/website_image_header.jpg";
  } else {
    image.src = "img/website_image_header_dark.jpg";
  }
}


// Step 3: Register a 'click' event listener for the theme button,
//             and tell it to use toggleDarkMode as its callback function
toggleButton.addEventListener("click", toggleDarkMode);


/*** Form Handling ***
  
  Purpose:
  - When the user submits the RSVP form, the name and state they 
    entered should be added to the list of participants.

  When To Modify:
  - [ ] Project 6 (REQUIRED FEATURE)
  - [ ] Project 6 (STRETCH FEATURE) 
  - [ ] Project 7 (REQUIRED FEATURE)
  - [ ] Project 9 (REQUIRED FEATURE)
  - [ ] Any time between / after
***/

// Step 1: Add your query for the submit RSVP button here

const submitButton = document.getElementById("rsvp-button");


let count = 3;

const addParticipant = (event, person) => {
  // const name = document.getElementById("name").value; 
  // const state = document.getElementById("state").value; 
  const message = "🌞 " + person.name + " from " + person.state + " has RSVP'd.";
  const newParticipant = document.createElement("p");
  newParticipant.textContent = message;
  const rsvpDiv = document.querySelector(".participants");
  rsvpDiv.appendChild(newParticipant);

  
  const countMessage = document.getElementById("rsvp-count");
  count++; 
  countMessage.textContent = "⭐" + count + " people have RSVP'd to this event!";

  event.preventDefault();
}



/*** Form Validation ***
  
  Purpose:
  - Prevents invalid form submissions from being added to the list of participants.

  When To Modify:
  - [ ] Project 7 (REQUIRED FEATURE)
  - [ ] Project 7 (STRETCH FEATURE)
  - [ ] Project 9 (REQUIRED FEATURE)
  - [ ] Any time between / after
***/

// Step 1: We actually don't need to select the form button again -- we already did it in the RSVP code above.

// Step 2: Write the callback function
const validateForm = (event) => {
  event.preventDefault();
  let containsErrors = false;

  var rsvpInputs = document.getElementById("rsvp-form").elements;

  let person = {
    name: rsvpInputs[0].value, // accesses and saves value of first input
    state: rsvpInputs[1].value,
    email:rsvpInputs[2].value
    // add more properties here
  }
  // TODO: Loop through all inputs
  for(let i = 0; i < rsvpInputs.length; i++){
    if(rsvpInputs[i].value.length < 2){
      containsErrors=true;
      rsvpInputs[i].classList.add("error");
    }
    else{
      rsvpInputs[i].classList.remove("error");
    }
  }

  // const email = document.getElementById("email");
  // if(!email.value.includes(".com") || !email.value.includes("@")){
  //   containsErrors=true;
  //   email.classList.add("error");
  // }
  // else{
  //   email.classList.remove("error");
  // }

  const email = document.getElementById("email");
   if(!person.email.includes(".com") || !person.email.includes("@")){
    containsErrors=true;
    email.classList.add("error");
  }
  else{
    email.classList.remove("error");
  }

  

  if (!containsErrors) {
    addParticipant(event, person); // Pass the event so it doesn’t reload the page
    toggleModal(person);
    for (let i = 0; i < rsvpInputs.length; i++) {
      rsvpInputs[i].value = "";
    }
  }


}

// Step 3: Replace the form button's event listener with a new one that calls validateForm()
submitButton.addEventListener("click", validateForm);

/*** Animations [PLACEHOLDER] [ADDED IN UNIT 8] ***/
/*** Modal ***
  
  Purpose:
  - Use this starter code to add a pop-up modal to your website.

  When To Modify:
  - [ ] Project 9 (REQUIRED FEATURE)
  - [ ] Project 9 (STRETCH FEATURE)
  - [ ] Any time after
***/

const toggleModal = (person) => {
    let modal = document.getElementById("success-modal");
    
    // TODO: Update modal display to flex
    modal.style.display = "flex";

    // TODO: Update modal text to personalized message
    let modalText = modal.querySelector("#modal-text");
    modalText.textContent = "Thanks for registering " + person.name + "! We've sent the details to " + person.email + "!";

    // Set modal timeout to 5 seconds
    let intervalId = setInterval(animateImage, 500);
    setTimeout(() => {
        modal.style.display = 'none';
        clearInterval(intervalId);
    }, 5000);
}

// TODO: animation variables and animateImage() function
let rotateFactor = 0; 
const modalImage = document.getElementById("modal-image");
const animateImage = () => {
  if(rotateFactor == 0){
    rotateFactor = -10;
  }
  else{
    rotateFactor = 0;
  }
  modalImage.style.transform = `rotate(${rotateFactor}deg)`;
}